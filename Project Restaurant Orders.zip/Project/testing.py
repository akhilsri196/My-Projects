import operator
from datetime import *
from flask import Flask, request,jsonify
from twilio.twiml.messaging_response import MessagingResponse
from openpyxl import load_workbook, Workbook 

app = Flask(__name__)
app.config["DEBUG"] = True

list_food_menu=[]
list_order_details=[]
#http://localhost:5000/api/restaurantwise?restaurantid=tuckshop
@app.route('/api/restaurantwise', methods=['GET'])
def api_id():
    parse_data()
    #print(list_food_menu)
    if 'restaurantid' in request.args:
        id = request.args['restaurantid']
    if 'date' in request.args:
        date = request.args['date']
    results = []
    count_of_orders=0
    for order in range(0,len(list_order_details)):
        dicttest = list_order_details[order]
        if(dicttest['restaurantid'] == id):
            count_of_orders=count_of_orders+1
    ret="Total Sales Sample - "+str(count_of_orders)
    return jsonify(ret)

#http://localhost:5000/api/most_ordered_of_the_day
@app.route('/api/most_ordered_of_the_day', methods=['GET'])
def order_of_the_day():
    parse_data()
    result={}
    for order in range(0,len(list_order_details)):
        dicttest = list_order_details[order]
        oditems=dicttest['orderedItems']
        itemnameelement = oditems[15:-1]
        finalename=itemnameelement.split(',')[0]
        foodname=finalename[0:-1]
        if(foodname in result.keys()):
            result[foodname]=result[foodname]+1
        else:
            result[foodname]=1
        count_of_orders=max(result.items(), key=operator.itemgetter(1))[0]

    ret="Most sold item for the day - "+str(count_of_orders)
    return jsonify(ret)

def parse_data():
    cols_food_menu = ["itemname","availabletime"]
    cols_order_details = ["orderid","restaurantid", "orderedItems", "billamount","timestamp"]
    d1={}
    d2={}
    wb = load_workbook('Smartq Data.xlsx')
    ws1 = wb['food menu']
    ws2 = wb['order details']
    for row in ws1.values:
        for col in range(0,2):
            d1[cols_food_menu[col]]=row[col]
        list_food_menu.append(d1)
        d1={}
    #print(list_food_menu)

    for row in ws2.values:
        for col in range(0,5):
            d2[cols_order_details[col]]=row[col]
        list_order_details.append(d2)
        d2={}

if __name__ == "__main__":
    app.run()
    
    
